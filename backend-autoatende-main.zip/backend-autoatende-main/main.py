import os
import json
import requests
from dotenv import load_dotenv
from firebase_functions import https_fn, firestore_fn
from firebase_admin import initialize_app, firestore
from openai import OpenAI

# Carrega as variáveis de ambiente do arquivo .env
load_dotenv()

# Inicializa o app do Firebase Admin
initialize_app()

# Instância do cliente Firestore
db = firestore.client()

# Instância do cliente OpenAI (pegando a chave do ambiente)
openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

@https_fn.on_request()
def whatsapp_webhook(req: https_fn.Request) -> https_fn.Response:
    """
    Webhook para receber mensagens de entrada do WhatsApp.
    """
        # Verifica token de verificação da Meta (Webhook Challenge)
        if req.method == "GET":
            mode = req.args.get("hub.mode")
            token = req.args.get("hub.verify_token")
            challenge = req.args.get("hub.challenge")
            
            # Substitua "MEU_TOKEN_SECRETO" pelo token que você configurar no painel da Meta
            if mode == "subscribe" and token == "MEU_TOKEN_SECRETO":
                return https_fn.Response(challenge, status=200)
            return https_fn.Response("Token inválido", status=403)

        # Aceita apenas requisições POST para recebimento de mensagens
        if req.method != "POST":
            return https_fn.Response("Método não permitido", status=405)

        # Extrai o JSON recebido
        data = req.get_json(silent=True)
        if not data:
            return https_fn.Response("Payload JSON inválido", status=400)

        # Retorna 200 imediatamente para a Meta não reenviar a mensagem
        # A Meta exige que o webhook responda 200 OK rapidamente
        response_to_meta = https_fn.Response("Sucesso", status=200)

        # Extração dos dados no formato da API Oficial da Meta (Cloud API)
        try:
            entry = data.get("entry", [])[0]
            changes = entry.get("changes", [])[0]
            value = changes.get("value", {})
            messages = value.get("messages", [])
            
            if not messages:
                return response_to_meta # Não é uma mensagem (pode ser status de leitura, etc)
                
            msg_data = messages[0]
            
            telefone = str(msg_data.get("from")) # Número de quem enviou
            message_id = str(msg_data.get("id"))
            
            # Verifica se é uma mensagem de texto
            if msg_data.get("type") != "text":
                 return response_to_meta
                 
            texto = msg_data.get("text", {}).get("body")

        except (IndexError, AttributeError) as e:
             print(f"Estrutura de payload inesperada: {e}")
             return response_to_meta

        if not telefone or not texto or not message_id:
            return response_to_meta

        # Referência para o documento do usuário
        user_ref = db.collection("usuarios").document(telefone)
        user_doc = user_ref.get()

        # Verifica se o usuário existe, se não, cria
        if not user_doc.exists:
            user_ref.set({
                "nome": "Cliente Novo",
                "status": "PROCESSING_AI"
            })

        # Referência para a mensagem na subcoleção
        message_ref = user_ref.collection("mensagens").document(message_id)

        # Salva a mensagem recebida
        message_ref.set({
            "texto": texto,
            "direcao": "entrada",
            "criadoEm": firestore.SERVER_TIMESTAMP
        })

        # Retorna status HTTP 200 de sucesso para a Meta
        return response_to_meta

    except Exception as e:
        print(f"Erro ao processar webhook: {e}")
        return https_fn.Response("Erro interno", status=500)

@firestore_fn.on_document_created(document="usuarios/{telefone}/mensagens/{message_id}")
def process_ai_response(event: firestore_fn.Event[firestore_fn.DocumentSnapshot | None]) -> None:
    """
    Gatilho do Firestore acionado sempre que uma nova mensagem é criada.
    Processa a inteligência artificial para responder ao usuário.
    """
    if event.data is None:
        return

    mensagem_data = event.data.to_dict()
    
    # 1. Trava: Se a mensagem for de saída, ignora para evitar loop infinito
    if mensagem_data.get("direcao") == "saida":
        return

    telefone = event.params.get("telefone")
    if not telefone:
        return

    # Referências no Firestore
    user_ref = db.collection("usuarios").document(telefone)
    user_doc = user_ref.get()

    if not user_doc.exists:
        return

    user_data = user_doc.to_dict()
    
    # 2. Trava: Se um humano assumiu o atendimento, a IA não responde
    if user_data.get("status") == "HUMAN_TAKEOVER":
        return

    # 3. Processamento da IA apenas se o status for PROCESSING_AI
    if user_data.get("status") == "PROCESSING_AI":
        try:
            mensagens_ref = user_ref.collection("mensagens")
            
            # Busca as últimas 10 mensagens ordenadas pela data de criação
            ultimas_mensagens = mensagens_ref.order_by(
                "criadoEm", direction=firestore.Query.ASCENDING
            ).limit(10).stream()

            # Formata o histórico para a API da OpenAI
            historico_openai = [
                {
                    "role": "system",
                    "content": "Você é um assistente virtual de atendimento comercial amigável e prestativo. Responda de forma clara, objetiva e educada."
                }
            ]

            for msg_doc in ultimas_mensagens:
                msg_dict = msg_doc.to_dict()
                role = "user" if msg_dict.get("direcao") == "entrada" else "assistant"
                historico_openai.append({
                    "role": role,
                    "content": msg_dict.get("texto", "")
                })

            # Chamada à API da OpenAI (modelo gpt-4o-mini)
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=historico_openai
            )

            resposta_ia = response.choices[0].message.content

            # Salva a resposta da IA na subcoleção de mensagens com direção "saida"
            mensagens_ref.add({
                "texto": resposta_ia,
                "direcao": "saida",
                "criadoEm": firestore.SERVER_TIMESTAMP
            })

        except Exception as e:
            print(f"Erro ao processar resposta da IA para {telefone}: {e}")

@firestore_fn.on_document_created(document="usuarios/{telefone}/mensagens/{message_id}")
def send_whatsapp_message(event: firestore_fn.Event[firestore_fn.DocumentSnapshot | None]) -> None:
    """
    Gatilho do Firestore acionado sempre que uma nova mensagem é criada.
    Verifica se a direção é 'saida' e dispara a requisição HTTP para o gateway do WhatsApp.
    """
    if event.data is None:
        return

    mensagem_data = event.data.to_dict()

    # Só processa mensagens que foram geradas para sair
    if mensagem_data.get("direcao") != "saida":
        return

    telefone = event.params.get("telefone")
    texto = mensagem_data.get("texto")

    if not telefone or not texto:
        return

    whatsapp_api_url = os.environ.get("WHATSAPP_API_URL")
    whatsapp_api_token = os.environ.get("WHATSAPP_API_TOKEN")

    if not whatsapp_api_url or not whatsapp_api_token:
        print("Erro: Credenciais do WhatsApp não configuradas no ambiente.")
        return

    try:
        # Configura os headers para a requisição HTTP (Cloud API)
        headers = {
            "Authorization": f"Bearer {whatsapp_api_token}",
            "Content-Type": "application/json"
        }
        
        # Payload no padrão da API Oficial do WhatsApp Cloud
        payload = {
            "messaging_product": "whatsapp",
            "to": telefone,
            "type": "text",
            "text": {
                "body": texto
            }
        }

        # Realiza o POST para o gateway oficial da Meta
        response = requests.post(whatsapp_api_url, headers=headers, json=payload, timeout=10)
        
        if response.status_code in (200, 201):
            print(f"Mensagem enviada com sucesso para {telefone}")
        else:
            print(f"Erro no gateway do WhatsApp ({response.status_code}): {response.text}")

    except Exception as e:
        print(f"Erro na requisição para o WhatsApp (telefone: {telefone}): {e}")
