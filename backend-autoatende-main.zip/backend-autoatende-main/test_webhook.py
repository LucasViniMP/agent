import requests
import json
import time

# URL local do Firebase Emulator ou da função deployada.
# Substitua pela URL real após rodar o emulador ou fazer o deploy.
# Exemplo emulador: "http://127.0.0.1:5001/SEU_PROJETO/us-central1/whatsapp_webhook"
WEBHOOK_URL = "http://127.0.0.1:5001/autoatende-test/us-central1/whatsapp_webhook"

def simular_mensagem(telefone, texto, message_id):
    """
    Envia uma requisição POST simulando um webhook do WhatsApp
    """
    payload = {
        "telefone": telefone,
        "texto": texto,
        "id_da_mensagem": message_id
    }
    
    headers = {
        "Content-Type": "application/json"
    }

    print(f"\n[+] Enviando mensagem de {telefone}: '{texto}'")
    
    try:
        response = requests.post(WEBHOOK_URL, json=payload, headers=headers)
        print(f"Status HTTP: {response.status_code}")
        print(f"Resposta: {response.text}")
    except requests.exceptions.ConnectionError:
        print(f"Erro: Não foi possível conectar a {WEBHOOK_URL}.")
        print("Certifique-se de que o emulador do Firebase está rodando ou atualize a URL para a função em produção.")

if __name__ == "__main__":
    print("=== Teste de Simulação AutoAtende+ ===")
    
    telefone_teste = "5511999999999"
    
    # Simula a primeira mensagem do cliente
    simular_mensagem(
        telefone=telefone_teste, 
        texto="Olá, gostaria de saber os horários de funcionamento.", 
        message_id="msg_001"
    )
    
    print("Aguardando 5 segundos para a próxima mensagem...")
    time.sleep(5)
    
    # Simula uma segunda mensagem
    simular_mensagem(
        telefone=telefone_teste, 
        texto="Vocês atendem finais de semana?", 
        message_id="msg_002"
    )
